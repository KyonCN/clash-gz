## 游戏规则  
这里存放一些个人制作的游戏规则碎片  

| 规则文件名 | 游戏名 | 区服 | 来源 |
|:-:|:-:|:-:|:-:|
| Microsoft-Flight-Simulator.yaml | 微软模拟飞行 | 全区服 | UU加速器提取 |
| Overwatch2_Asia(Singapore).yaml | 守望先锋2 | 亚服（新加坡） | 自制 |
